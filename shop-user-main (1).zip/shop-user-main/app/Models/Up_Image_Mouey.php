<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Up_Image_Mouey extends Model
{
    use HasFactory;
    protected $fillable = [
        'number_count',
        'number_count',
        'number_count',
    ];
    
}
