<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PasswordMoney extends Model
{
    use HasFactory;
    protected $fillable = [
        'password_modey',
        'idUser'
    ];
}
