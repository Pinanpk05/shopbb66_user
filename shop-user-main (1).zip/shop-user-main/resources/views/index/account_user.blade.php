@extends('layouts.home')
@section('content')


@include('layouts.navbarFooter') 
@endsection