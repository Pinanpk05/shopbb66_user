<nav>
    <div class="nav nav-tabs" id="nav-tab" role="tablist">
      <a href="{{ URL::to('won-prize')}}" class="nav-link active" >หน้ารวม</a>
      <a href="{{ URL::to('program/180Shopee')}}" class="nav-link " >180Shopee</a>
      <a href="{{ URL::to('program/300Lazada')}}" class="nav-link" >300Lazada</a>
      <a href="{{ URL::to('program/180Shop')}}" class="nav-link" >180Shop</a>
      <a href="{{ URL::to('program/60Advice')}}" class="nav-link" >60Advice</a>
      <a href="{{ URL::to('program/300 JD')}}" class="nav-link" >300 JD</a>
      <a href="{{ URL::to('program/300Chilindo')}}" class="nav-link" >300Chilindo</a>
      <a href="{{ URL::to('program/1200CENTRAL')}}" class="nav-link" >1200CENTRAL</a>
      <a href="{{ URL::to('program/180PowerBuy')}}" class="nav-link" >180PowerBuy</a>
    </div>
  </nav>