<div class="head">
  <p class="center text-head">รายชื่อธุระกิจ</p>
</div>
<div class="container">
  <div class="row row-cols-4 center-shop">
    <div class="col-6 col-sm-6 col-md-3 col-lg-3">
      <a href="{{ URL('topping/180Shopee')}}" class="text-decoration">
        <img src="{{asset('/image/shop-21.png')}}" class="width-height " alt="..."  >
        <br>
         <span class="center-shop">180Shopee</span>
        </a>
    </div>
    <div class="col-6 col-sm-6 col-md-3 col-lg-3" >
      <a href="{{ URL('topping/300Lazada')}}" class="text-decoration">
        <img src="{{asset('/image/shop-22.png')}}"  class="width-height" alt="...">
      <br>
      <span class="center-shop">300Lazada</span>
      </a>
    </div>
    <div class="col-6 col-sm-6 col-md-3 col-lg-3">
      <a href="{{ URL('topping/60Advice')}}" class="text-decoration">
        <img src="{{asset('/image/Advice.png')}}"  class="width-height" alt="...">
      <br>
      <span class="center-shop">60Advice</span>
      </a>
    </div>
    <div class="col-6 col-sm-6 col-md-3 col-lg-3">
      <a href="{{ URL('topping/60Advice')}}" class="text-decoration">
        <img src="{{asset('/image/Advice.png')}}"  class="width-height" alt="...">
      <br>
      <span class="center-shop">60Advice</span>
      </a>
    </div>
  </div>
</div>

{{-- 
<table class="table table-bordered  width-height">
    <tbody>
      <tr class="img-shop box-shop center  ">
        <td class="col-3 col-sm-3 col-md-4 " >
           <a href="{{ URL('topping/180Shopee')}}" class="text-decoration">
            <img src="{{asset('/image/shop-21.png')}}" class="img-shop-tb-2 " alt="..."  >
            <br>
             <span class="center-shop">180Shopee</span>
           </a>
        </td>
        <td class="col-3 col-sm-3 col-md-4 nameShop " >
            <a href="{{ URL('topping/300Lazada')}}" class="text-decoration">
              <img src="{{asset('/image/shop-22.png')}}"  class="img-shop-tb-2" alt="...">
            <br>
            <span class="center-shop">300Lazada</span>
            </a>
        </td>
            <td class="col-3 col-sm-3 col-md-4 nameShop" >
                <a href="{{ URL('topping/180Shop')}}" class="text-decoration">
                  <img src="{{asset('/image/shop-23.png')}}"  class="img-shop-tb-2" alt="..." >
              <br>
                <span class="center-shop">180Shop</span>
                </a>
            </td>
      </tr>
      <tr class="img-shop box-shop center">
        <td class="col-3 col-sm-3 col-md-4 nameShop" >
            <a href="{{ URL('topping/60Advice')}}" class="text-decoration">
              <img src="{{asset('/image/Advice.png')}}"  class="img-shop-tb-2" alt="...">
            <br>
            <span class="center-shop">60Advice</span>
            </a>
        </td>
        <td class="col-3 col-sm-3 col-md-4 nameShop" >
            <a href="{{ URL('topping/300 JDL')}}" class="text-decoration">
              <img src="{{asset('/image/shop-25.png')}}" class="img-shop-tb-2" alt="...">
           <br>
            <span class="center-shop">300 JD</span>
            </a>
        </td>
            <td class="col-3 col-sm-3 col-md-4 nameShop" >
               <a href="{{ URL('topping/300Chilindo')}}" class="text-decoration">
                <img src="{{asset('/image/shop-26.png')}}"  class="img-shop-tb-2" alt="...">
                <br>
                <span class="center-shop">300Chilindo</span>
               </a>
            </td>
      </tr>
      <tr class="img-shop box-shop center nameShop">
        <td class="col-3 col-sm-3 col-md-4 " >
            <a href="{{ URL('topping/1200CENTRAL')}}" class="text-decoration">
              <img src="{{asset('/image/shop-27.png')}}"  class="img-shop-tb-2" alt="...">
            <br>
            <span class="center-shop">1200CENTRAL</span>
            </a>
        </td>
        <td class="col-3 col-sm-3 col-md-4 nameShop" >
            <a href="{{ URL('topping/180PowerBuy')}}" class="text-decoration">
              <img src="{{asset('/image/shop-28.png')}}" class="img-shop-tb-2" alt="...">
            <br>
            <span class="center-shop">180PowerBuy</span>
            </a>
        </td>
      </tr>
    </tbody>
  </table> --}}
  <br>
  <br>
  <br>  
  
 