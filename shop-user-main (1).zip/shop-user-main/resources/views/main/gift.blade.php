<div class="head">
    <p class="center text-head" onclick="locationReload()">ของขวัญ</p>
</div>
<div class="gift ">
  <img src="{{asset('/image/gift.png')}}" class="img-gift" alt="...">
  <p>ไม่มีข้อมูล</p>
</div>
{{--  --}}
  <br>
  <br>
  <br>